#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;

void test()
{
	char a = 'a';
	int b = 10;

	int c = static_cast<int>(a);
}

class Person
{
	virtual void show();
};


class Peson1 :public Person
{
	virtual void show();
	
};


void test02()
{
	Peson1 *p1;
	Person *p2;

	Peson1* p = dynamic_cast<Peson1*>(p2);
	//Person *p = dynamic_cast<Person *>(p1);




}





void test01()
{
	double a = 3.14;
	int b = 10;
	//����ת��������������
	double c = dynamic_cast<double>(a);



}







int main(){



	system("pause");
	return EXIT_SUCCESS;
}