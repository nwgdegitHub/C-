#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
class Person
{
public:
	Person()
	{
		n++;
		sun += n;
	}
	static void get(){ n = 0, sun = 0; };
	static int getsun();


private:
	static int n;
	static int sun;
};

int Person::n=0;
int Person::sun=0;
void getsun(int sun);
int  Person::getsun()
{
	return sun;
}


void test()
{
	Person::get();
	Person *a = new Person[5];
	delete[]a;
	a = NULL;
	int i = Person::getsun();
	cout << i << endl;
}


class Person
{
public:
	Person()
	{
		
	
	}


	static int  a;
	static int sum;

};






int main(){


	test();
	system("pause");
	return EXIT_SUCCESS;
}