#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

class myexception:public exception
{
public:
	myexception(string err)
	{
		this->err = err;	
	}
	virtual  ~myexception()
	{
	}
	virtual const char *  what() const
	{
		return this->err.c_str();
	}
	 string err;
};


class Person
{
public:
	Person(string name, int age)
	{
		this->name = name;

		if (age < 0 || age >200)
		{
			throw myexception (string("����������䲻�ԣ�"));
		}
		else
		{
			this->age = age;
		}	
	}
	string name;
	int  age;
};

void test()
{
	//Person * p1=new Person("����",1000);
	try{ Person("����",1000); }

	catch (myexception &p)
	{
		cout << p.what() << endl;;
	}
}


int main()
{
	test();
	system("pause");
	return EXIT_SUCCESS;
}