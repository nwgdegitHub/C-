#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
#include<stdexcept>
#include<iomanip>
//#inlcude<>
using namespace std;

class Person
{
public:
	Person(string name, int age)
	{
		this->name = name;
		if (age < 0 || age>200)
		{
			//throw out_of_range("����Խ��");
			throw length_error((string)"���Ǵ�ħ��");
		}

		this->age = age;	
	}

	string name;
	int age;
};

void test()
{
	try{ Person("����", 3000); }

	catch (length_error &p)
	{
		cout << p.what() << endl;
	}
}


class Person01
{
public:
	Person01(string name, int age)
	{
		this->name = name;

		if (age < 0 || age>150)
		{
			throw out_of_range((string)"�������");

		}

		this->age = age;
	}
	string name;
	int age;

};



void test01()
{
	//Person01 p1("wang", 1000);
	try{ Person01 p1("wang", 1000); }
	catch (out_of_range &p)
	{
		cout << p.what() << endl;
	}
}




class myexception:public exception
{
public:

	myexception(string err)
	{
		this->err = err;
	}

	virtual  ~myexception()
	{
		
	
	}
	virtual const char *  what() const
	{
		//��errת��Ϊchar*
		return this->err.c_str();
	}

	string err;
};


class Person02 :public exception
{
public:

	Person02(string name, int age)
	{
		this->name = name;
		if (age >200)
		{
			throw out_of_range((string)"hhhhh");
		}
		this->age = age;
	}

	~Person02()
	{
	
	
	}
	string name;
	int age;
};



void test02()
{
	//Person p1("����", 100);
	try{ Person02 p1("����", 300); }
	catch (out_of_range &p)
	{
		cout << p.what() << endl;
	}


}



int comper(int a,int b)
{
	if (b == 0)
	{
		throw 'a';
	}
	return a / b;
}


void test03()
{
	int a = 10;
	int b = 0;

	try{ comper(a, b); }
	catch (int)
	{
		cout << "int���ʹ���" << endl;
	}
	//catch (...)
	//{
	//	cout << "��������" << endl;
	//}
	throw;
}

class S {
public:
	~S() { cout << "S "; }
};
char fun()
{
	S s1;
	throw('T');
	return 'O';
}


void main02()
{
	try { cout << fun(); }
	catch (char c) { cout << c; }
	system("pause");
}





int main() {
	cout.fill('*');
	cout.width(10);
	cout << setiosflags(ios::left) << 123.45 << endl;
	system("pause");
}



void main01()

{

	//test();
	//test01();
	//test02();
	//test03();

	//try{ test03(); }
	//catch (char)
	//{
	//	cout << "char����" << endl;
	//
	//}
	cout << "1. Hello! " << endl;
	//cout << "1. " << setfill(' ') << "Hello! " << endl;
	cout << "1. " << ' ' << "Hello! \n";
	cout << "1. " << ' ' << "Hello! \n";
	system("pause");
	//return EXIT_SUCCESS;
}