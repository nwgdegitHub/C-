#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
class Father
{
public:
	virtual void show() = 0;
};


class Son :public Father
{
public:
	virtual void show()
	{
		cout << "��ָ���쳣" << endl;
	}
};

class Son1 :public Father
{
public:
	virtual void show()
	{
		cout << "ָ�����" << endl;
	}
};


void dowork()
{
	Son p1;
	throw p1;
	//throw  Son1();
}



void test()
{
	try{ dowork(); }
	catch (Son &p)
	{
		p.show();
	}
	catch (Son1 &p)
	{
		p.show();
	}


}







int main(){

	test();

	system("pause");
	return EXIT_SUCCESS;
}