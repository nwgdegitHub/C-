#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

class myerrperson :public exception
{
public:
	myerrperson(string err)
	{
		this->err = err;
		cout << "�вι���" << endl;
	}
	virtual  ~myerrperson()
	{
		cout << "��������" << endl;
	}
	virtual const char *  what() const
	{	//.c_str()��char*ת��Ϊstring
		return this->err.c_str();
	}
	string err;
};


class Person
{
public:
	Person(string name, int age)
	{
		this->name = name;
		if (age < 0 || age >200)
		{
			throw myerrperson ("�����쳣");;
		}
		this->age = age;
	}
	string name;
	int age;
};


void show()
{
	try{ Person p1("����", 300); }
	catch (myerrperson &p)
	{

		cout << p.what() << endl;
	}
}





int main()
{
	show();
	system("pause");
	return EXIT_SUCCESS;
}