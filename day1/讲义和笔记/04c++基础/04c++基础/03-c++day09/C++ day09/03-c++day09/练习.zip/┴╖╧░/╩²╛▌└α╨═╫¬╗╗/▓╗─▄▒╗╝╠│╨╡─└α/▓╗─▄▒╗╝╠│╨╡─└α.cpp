#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
template<class T>
class Person
{
	friend T;

private:
	Person(){}
	~Person(){}
};



class son :virtual public Person < son >
{



};

class son :public Person
{
public:

};


void test()
{

	son p1;

}


int main(){

	test();

	system("pause");
	return EXIT_SUCCESS;
}