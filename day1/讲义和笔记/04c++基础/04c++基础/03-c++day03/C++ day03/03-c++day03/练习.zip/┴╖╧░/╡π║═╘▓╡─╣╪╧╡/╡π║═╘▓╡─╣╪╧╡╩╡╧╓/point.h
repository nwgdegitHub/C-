#pragma once
#include<iostream>

class point
{
public:
	void setX(int a);
	void setY(int b);

	int getX();
	int getY();

private:
	int X;
	int Y;

};
