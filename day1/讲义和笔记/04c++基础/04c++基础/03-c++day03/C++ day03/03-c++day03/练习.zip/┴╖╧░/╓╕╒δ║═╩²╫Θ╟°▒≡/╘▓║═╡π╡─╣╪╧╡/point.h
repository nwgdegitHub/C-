#pragma once

#include<iostream>
using namespace std;

//����
class point
{
public:
	void setX(int a);
	void setY(int b);


	int getX();
	int getY();

private:
	int X;
	int Y;

};




