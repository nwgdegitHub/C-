#include"point.h"



void point::setX(int a){ X = a; };

void point::setY(int b){ Y = b; };

int point::getX(){ return X; };

int point::getY(){ return Y; };





