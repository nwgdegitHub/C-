#pragma once
#include<iostream>
using namespace std;
#
class circle
{
public:
	void set(int )




private:
	int r;
	point ciclk;
};

